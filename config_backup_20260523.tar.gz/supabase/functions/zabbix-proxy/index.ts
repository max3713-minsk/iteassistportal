import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const ZABBIX_TIMEOUT = 15000;
const cache = new Map<string, { data: unknown; ts: number }>();
function getCached(key: string, ttlMs: number): unknown | null {
  const entry = cache.get(key);
  if (entry && Date.now() - entry.ts < ttlMs) return entry.data;
  return null;
}
function setCache(key: string, data: unknown) {
  cache.set(key, { data, ts: Date.now() });
  if (cache.size > 100) {
    const oldest = [...cache.entries()].sort((a, b) => a[1].ts - b[1].ts)[0];
    if (oldest) cache.delete(oldest[0]);
  }
}

async function fetchWithTimeout(url: string, options: RequestInit, timeout = ZABBIX_TIMEOUT): Promise<Response> {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } catch (e) {
    if (e instanceof Error && (e.name === "AbortError" || /aborted/i.test(e.message))) {
      throw new Error(`Zabbix-сервер недоступен (timeout ${timeout} мс): ${url}`);
    }
    if (e instanceof Error && /network|fetch failed|ECONNREFUSED|ENOTFOUND/i.test(e.message)) {
      throw new Error(`Zabbix-сервер недоступен: ${e.message}`);
    }
    throw e;
  } finally {
    clearTimeout(id);
  }
}

function jsonRpc(method: string, params: unknown, auth?: string, id = 1) {
  const body: Record<string, unknown> = { jsonrpc: "2.0", method, params, id };
  if (auth) body.auth = auth;
  return JSON.stringify(body);
}

const ok = (data: unknown) => new Response(JSON.stringify(data), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
const fail = (error: string, status = 500) => new Response(JSON.stringify({ error }), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });

const authTokenCache = new Map<string, { token: string; ts: number }>();
const AUTH_TTL = 60 * 60 * 1000;
async function getAuthToken(cacheKey: string, apiUrl: string, user: string, password: string): Promise<string> {
  const entry = authTokenCache.get(cacheKey);
  if (entry && Date.now() - entry.ts < AUTH_TTL) return entry.token;
  const res = await fetchWithTimeout(apiUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: jsonRpc("user.login", { username: user, password }),
  });
  const data = await res.json();
  if (!data.result) throw new Error("Ошибка авторизации Zabbix");
  authTokenCache.set(cacheKey, { token: data.result, ts: Date.now() });
  return data.result;
}

function getActionDef(action: string, extraParams?: Record<string, unknown>): { method: string; params: Record<string, unknown>; cacheTtl: number } | null {
  switch (action) {
    case "getHosts":
      return { method: "host.get", params: { output: ["hostid","host","name","status","available"], selectInterfaces: ["ip","dns","port","type"], selectGroups: ["groupid","name"], sortfield: "name", ...extraParams }, cacheTtl: 60000 };
    case "getProblems":
      return { method: "problem.get", params: { output: "extend", selectAcknowledges: "extend", selectTags: "extend", recent: true, sortfield: ["eventid"], sortorder: "DESC", limit: 100, ...extraParams }, cacheTtl: 30000 };
    case "getAlerts":
      return { method: "trigger.get", params: { output: ["triggerid","description","priority","value","lastchange","status"], selectHosts: ["hostid","name"], filter: { value: 1 }, sortfield: "priority", sortorder: "DESC", limit: 100, only_true: true, active: true, expandDescription: true, ...extraParams }, cacheTtl: 30000 };
    case "getHostAvailability":
      return { method: "host.get", params: { output: ["hostid","host","name","available"], selectInterfaces: ["ip"], ...extraParams }, cacheTtl: 60000 };
    case "getItems":
      return { method: "item.get", params: { output: ["itemid","name","key_","lastvalue","lastclock","units","state","status"], selectHosts: ["hostid","name"], sortfield: "name", limit: 500, ...extraParams }, cacheTtl: 30000 };
    case "getGraphs":
      return { method: "graph.get", params: { output: ["graphid","name","width","height"], selectHosts: ["hostid","name"], sortfield: "name", ...extraParams }, cacheTtl: 60000 };
    case "getScripts":
      return { method: "script.get", params: { output: ["scriptid","name","command","description","type","scope"], selectGroups: ["groupid","name"], ...extraParams }, cacheTtl: 60000 };
    case "getHostGroups":
      return { method: "hostgroup.get", params: { output: ["groupid","name"], sortfield: "name", ...extraParams }, cacheTtl: 120000 };
    case "getEvents":
      return { method: "event.get", params: { output: "extend", selectHosts: ["hostid","name"], sortfield: ["clock"], sortorder: "DESC", limit: 200, ...extraParams }, cacheTtl: 30000 };
    case "getRecentEvents":
      return { method: "event.get", params: { output: ["eventid","source","object","objectid","clock","value","name","severity","acknowledged"], selectHosts: ["hostid","name"], sortfield: ["clock"], sortorder: "DESC", limit: 10, value: 1, ...extraParams }, cacheTtl: 15000 };
    case "getTemplates":
      return { method: "template.get", params: { output: ["templateid","host","name","description"], sortfield: "name", ...extraParams }, cacheTtl: 300000 };
    case "getHistory":
      return { method: "history.get", params: { output: "extend", history: 0, sortfield: "clock", sortorder: "DESC", limit: 500, ...extraParams }, cacheTtl: 30000 };
    case "getTrends":
      return { method: "trend.get", params: { output: "extend", sortfield: "clock", sortorder: "DESC", limit: 1000, ...extraParams }, cacheTtl: 60000 };
    case "getClosedEvents":
      return { method: "event.get", params: { output: ["eventid","source","object","objectid","clock","value","name","severity","acknowledged","r_eventid"], selectHosts: ["hostid","name"], sortfield: ["clock"], sortorder: "DESC", limit: 200, value: 0, ...extraParams }, cacheTtl: 30000 };
    case "getTriggerCounts":
      return { method: "trigger.get", params: { output: ["triggerid","priority"], filter: { value: 1, status: 0 }, countOutput: false, ...extraParams }, cacheTtl: 30000 };
    case "getHostDetail":
      return { method: "host.get", params: { hostids: [extraParams?.hostid], output: "extend", selectInterfaces: "extend", selectGroups: "extend", selectParentTemplates: ["templateid","name","host"], selectTriggers: ["triggerid","description","priority","value"] }, cacheTtl: 60000 };
    case "getItemsByHost":
      return { method: "item.get", params: { hostids: [extraParams?.hostid], output: ["itemid","name","key_","lastvalue","lastclock","units","value_type","state","status"], sortfield: "name", limit: 1000 }, cacheTtl: 30000 };
    default:
      return null;
  }
}

export default async function handler(req: Request) {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const authHeader = req.headers.get("Authorization");
  if (!authHeader) return fail("Unauthorized", 401);

  const supabaseClient = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: authHeader } } }
  );
  const { data: { user }, error: authError } = await supabaseClient.auth.getUser();
  if (authError || !user) return fail("Unauthorized", 401);

  const supabaseAdmin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

  let body: any = {};
  try { body = await req.json(); } catch { /* empty */ }
  const explicitConnId = body.connection_id;
  let ZABBIX_URL = "", ZABBIX_USER = "", ZABBIX_PASSWORD = "", resolvedConnId = null;

  if (explicitConnId) {
    const { data: conn } = await supabaseAdmin.from("zabbix_connections").select("id, zabbix_url, zabbix_user, zabbix_password, is_active").eq("id", explicitConnId).maybeSingle();
    if (conn && conn.is_active) { ZABBIX_URL = conn.zabbix_url; ZABBIX_USER = conn.zabbix_user; ZABBIX_PASSWORD = conn.zabbix_password; resolvedConnId = conn.id; }
  }
  if (!ZABBIX_URL) {
    const { data: conns } = await supabaseAdmin.from("zabbix_connections").select("id, zabbix_url, zabbix_user, zabbix_password, is_default").eq("is_active", true).order("is_default", { ascending: false }).limit(1);
    if (conns && conns.length) { const c = conns[0]; ZABBIX_URL = c.zabbix_url; ZABBIX_USER = c.zabbix_user; ZABBIX_PASSWORD = c.zabbix_password; resolvedConnId = c.id; }
  }
  if (!ZABBIX_URL) return fail("Подключение Zabbix не сконфигурировано. Добавьте подключение в разделе «Подключения».");

  const apiUrl = `${ZABBIX_URL}/api_jsonrpc.php`;
  const headers = { "Content-Type": "application/json" };
  const { action, params: extraParams } = body;
  const connCacheKey = resolvedConnId ?? `legacy:${ZABBIX_URL}`;

  try {
    if (action === "testConnection") {
      try {
        const versionRes = await fetchWithTimeout(apiUrl, { method: "POST", headers, body: jsonRpc("apiinfo.version", {}) }, 10000);
        const versionData = await versionRes.json();
        if (!versionData.result) return ok({ ok: false, error: "invalid_url", message: "Не удалось получить версию Zabbix API." });
        const loginRes = await fetchWithTimeout(apiUrl, { method: "POST", headers, body: jsonRpc("user.login", { username: ZABBIX_USER, password: ZABBIX_PASSWORD }) }, 10000);
        const loginData = await loginRes.json();
        if (loginData.error) return ok({ ok: false, error: "auth_failed", message: `Неверные учётные данные.` });
        if (!loginData.result) return ok({ ok: false, error: "auth_failed", message: "Не удалось получить токен." });
        try { await fetchWithTimeout(apiUrl, { method: "POST", headers, body: jsonRpc("user.logout", [], loginData.result) }, 5000); } catch { }
        authTokenCache.delete(connCacheKey);
        return ok({ ok: true, data: { version: versionData.result } });
      } catch (err: any) { return ok({ ok: false, error: "network_error", message: err.message }); }
    }

    const actionDef = getActionDef(action, extraParams);
    if (!actionDef) return fail("Unknown action", 400);
    const cacheKey = `${connCacheKey}:${action}:${JSON.stringify(extraParams || {})}`;
    if (actionDef.cacheTtl > 0) {
      const cached = getCached(cacheKey, actionDef.cacheTtl);
      if (cached !== null) return ok({ result: cached, cached: true });
    }
    const authToken = await getAuthToken(connCacheKey, apiUrl, ZABBIX_USER, ZABBIX_PASSWORD);
    const dataResponse = await fetchWithTimeout(apiUrl, {
      method: "POST", headers,
      body: jsonRpc(actionDef.method, actionDef.params, authToken, 2),
    });
    const data = await dataResponse.json();
    if (data.error) {
      if (data.error.code === -32602 || data.error.data === "Session terminated") {
        authTokenCache.delete(connCacheKey);
        const newToken = await getAuthToken(connCacheKey, apiUrl, ZABBIX_USER, ZABBIX_PASSWORD);
        const retryRes = await fetchWithTimeout(apiUrl, {
          method: "POST", headers,
          body: jsonRpc(actionDef.method, actionDef.params, newToken, 3),
        });
        const retryData = await retryRes.json();
        if (retryData.error) return fail(`Zabbix API error: ${retryData.error.message || retryData.error.data}`);
        if (actionDef.cacheTtl > 0) setCache(cacheKey, retryData.result);
        return ok({ result: retryData.result });
      }
      return fail(`Zabbix API error: ${data.error.message || data.error.data}`);
    }
    if (actionDef.cacheTtl > 0) setCache(cacheKey, data.result);
    return ok({ result: data.result });
  } catch (err: any) {
    console.error("Zabbix proxy error:", err);
    const isUnreachable = /недоступен|timeout|aborted|network|fetch failed|ECONN|ENOTFOUND/i.test(err.message);
    return new Response(JSON.stringify({ error: err.message, fallback: isUnreachable }), {
      status: isUnreachable ? 200 : 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
}
