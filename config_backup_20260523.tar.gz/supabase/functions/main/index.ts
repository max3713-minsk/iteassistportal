import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

async function handler(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const path = url.pathname;
    console.log("🔵 Main router, path:", path);

    if (path === "/zabbix-proxy") {
      const module = await import("/app/functions/zabbix-proxy/index.ts");
      return await module.default(req);
    }
    if (path === "/manage-user") {
      const module = await import("/app/functions/manage-user/index.ts");
      return await module.default(req);
    }
    if (path === "/create-user") {
      const module = await import("/app/functions/create-user/index.ts");
      return await module.default(req);
    }
    if (path === "/holidays-sync") {
      const module = await import("/app/functions/holidays-sync/index.ts");
      return await module.default(req);
    }
    if (path === "/seafile-upload-typed") {
      const module = await import("/app/functions/seafile-upload-typed/index.ts");
      return await module.default(req);
    }
    if (path === "/protocol-export-seafile") {
      const module = await import("/app/functions/protocol-export-seafile/index.ts");
      return await module.default(req);
    }
    if (path === "/notification-dispatch") {
      const module = await import("/app/functions/notification-dispatch/index.ts");
      return await module.default(req);
    }

    return new Response(JSON.stringify({ error: "Function not found" }), {
      status: 404,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("❌ Handler error:", err);
    return new Response(JSON.stringify({ error: err.message, stack: err.stack }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
}

Deno.serve({ port: 9999, hostname: "0.0.0.0" }, handler);
